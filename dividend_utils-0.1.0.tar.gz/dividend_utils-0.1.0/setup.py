# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['dividend_utils']

package_data = \
{'': ['*']}

install_requires = \
['pandas==0.25.3', 'python-dateutil>=2.8.1,<3.0.0']

setup_kwargs = {
    'name': 'dividend-utils',
    'version': '0.1.0',
    'description': '处理除权除息的相关业务',
    'long_description': None,
    'author': 'Chaoying',
    'author_email': 'chaunceywe@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
