from dataclasses import dataclass, fields
from datetime import date
from decimal import Decimal
from typing import Any

from dividend_utils.enums import Exchange, FlowType

__all__ = ["Position", "Flow"]


@dataclass
class Position:
    """持仓."""

    fund_id: str  # 资金账户ID
    symbol: str  # 股票代码
    exchange: Exchange  # 交易所
    volume: int  # 持仓数量

    def __init__(self, **kwargs: Any):
        names = set([f.name for f in fields(self)])
        for k, v in kwargs.items():
            if k in names:
                setattr(self, k, v)


@dataclass
class Flow:
    """流水."""

    fund_id: str  # 资金账户ID
    symbol: str  # 股票代码
    exchange: Exchange  # 交易所
    ttype: FlowType  # 流水类别
    tdate: date  # 交易日期
    stkeffect: int = 0  # 股票变动
    fundeffect: Decimal = Decimal("0")  # 资金变动

    def __init__(self, **kwargs: Any):
        names = set([f.name for f in fields(self)])
        for k, v in kwargs.items():
            if k in names:
                setattr(self, k, v)
