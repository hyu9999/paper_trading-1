from enum import Enum, unique


@unique
class Exchange(str, Enum):
    """交易所."""

    CNSESH = "CNSESH"  # 上交所
    CNSESZ = "CNSESZ"  # 深交所


@unique
class FlowType(str, Enum):
    """流水类别."""

    BUY = "3"  # 买
    SELL = "4"  # 卖
    DIVIDEND = "5"  # 分红
    TAX = "6"  # 扣税


@unique
class DividendType(str, Enum):
    """分红类别."""

    CASH_DIVIDEND = "dividend_per_share_before_tax"  # 现金股利
    STOCK_DIVIDEND = "share_bonus_per_share"  # 股票股利
