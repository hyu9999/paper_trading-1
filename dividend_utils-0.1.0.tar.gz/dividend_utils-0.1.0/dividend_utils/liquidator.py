from dataclasses import asdict
from datetime import date
from decimal import Decimal
from typing import List, Optional

import pandas as pd

from dividend_utils.dividend import (
    get_dividend,
    get_dividend_record_date,
    get_open_position_date,
)
from dividend_utils.enums import DividendType, FlowType
from dividend_utils.models import Flow, Position
from dividend_utils.tax import calculate_tax

__all__ = ["liquidate_dividend", "liquidate_dividend_tax"]


def liquidate_cash_dividend(
    dividend_detail: pd.DataFrame, position: Position, liq_date: date
) -> Optional[Flow]:
    """清算现金股利."""
    rate, pay_date = get_dividend(dividend_detail, liq_date, DividendType.CASH_DIVIDEND)
    if rate and pay_date:
        cash_dividend = rate * position.volume
        return Flow(
            fund_id=position.fund_id,
            symbol=position.symbol,
            exchange=position.exchange,
            ttype=FlowType.DIVIDEND,
            tdate=pay_date,
            fundeffect=Decimal(round(cash_dividend, 3)),
        )
    else:
        return None


def liquidate_stock_dividend(
    dividend_detail: pd.DataFrame, position: Position, liq_date: date
) -> Optional[Flow]:
    """清算股票股利."""
    rate, pay_date = get_dividend(
        dividend_detail, liq_date, DividendType.STOCK_DIVIDEND
    )
    if rate and pay_date:
        stock_dividend = rate * position.volume
        return Flow(
            fund_id=position.fund_id,
            symbol=position.symbol,
            exchange=position.exchange,
            ttype=FlowType.DIVIDEND,
            tdate=pay_date,
            stkeffect=int(stock_dividend),
        )
    else:
        return None


def liquidate_dividend(
    dividend_detail: pd.DataFrame, position: Position, liq_date: date
) -> List[Flow]:
    """清算分红."""
    flow_list = []
    cash_flow = liquidate_cash_dividend(dividend_detail, position, liq_date)
    stock_flow = liquidate_stock_dividend(dividend_detail, position, liq_date)
    if cash_flow:
        flow_list.append(cash_flow)
    if stock_flow:
        flow_list.append(stock_flow)
    return flow_list


def liquidate_dividend_tax(
    dividend_detail: pd.DataFrame, order: Flow, flow_list: List[Flow]
) -> Optional[Flow]:
    """清算红利税."""
    flow_df = pd.DataFrame([asdict(flow) for flow in flow_list])
    flow_df.set_index("tdate")

    # 获取最近一次分红日期
    dividend_df = dividend_detail.tail(1).reset_index()
    record_date = get_dividend_record_date(dividend_df)

    # 过滤掉晚于最近一次分红日和登记日前持仓为0的流水
    flow_df = flow_df[flow_df["tdate"] <= record_date]
    if flow_df.empty or flow_df.stkeffect.sum() <= 0:
        return None

    # 获取建仓日
    open_position_date = get_open_position_date(flow_df)
    # 过滤掉早于建仓日的流水
    flow_df = flow_df[flow_df["tdate"] >= open_position_date]

    # 过滤出建仓日到最近一次分红日的分红记录
    dividend_df = dividend_detail.query(
        "(record_date >= @open_position_date) and (record_date <= @record_date)"
    )

    tax = 0.0
    dividend_df.reset_index(inplace=True)
    for index in range(len(dividend_df)):
        df = dividend_df.loc[[index]].reset_index()
        tax += calculate_tax(flow_df, df, abs(order.stkeffect), order.tdate)

    # 若持仓时间都大于一年则总税额为0
    if tax == 0:
        return None
    else:
        return Flow(
            fund_id=order.fund_id,
            symbol=order.symbol,
            exchange=order.exchange,
            ttype=FlowType.TAX,
            tdate=order.tdate,
            fundeffect=Decimal(str(-tax)),
        )
