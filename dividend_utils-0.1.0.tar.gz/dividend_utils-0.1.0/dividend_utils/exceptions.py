class DividendError(Exception):
    ...


class SecurityNotFoundError(Exception):
    """未找到该证券的分红记录."""
