from datetime import date
from typing import Optional, Tuple

import pandas as pd

from dividend_utils.enums import DividendType


def get_dividend_rate(df: pd.DataFrame, dividend_type: DividendType) -> float:
    """获取分红率.

    当分红类型为现金股利时, 返回`每股股利(税前)`.
    当分红类型为股票股利时, 返回`每股送股比例`.
    """
    df.fillna(0, inplace=True)
    return round(df.at[0, dividend_type.value], 3)  # type: ignore


def get_dividend_pay_date(df: pd.DataFrame) -> date:
    """获取派息日."""
    return df.at[0, "dividend_pay_date"].date()  # type: ignore


def get_dividend_record_date(df: pd.DataFrame) -> date:
    """获取股权登记日."""
    return df.at[0, "record_date"].date()  # type: ignore


def get_dividend(
    dividend_detail: pd.DataFrame, liq_date: date, dividend_type: DividendType
) -> Tuple[Optional[float], Optional[date]]:
    """获取分红率和派息日."""
    df = dividend_detail[
        (dividend_detail["record_date"] == str(liq_date))
        & (dividend_detail[dividend_type.value])
    ].reset_index()
    if not df.empty:
        return get_dividend_rate(df, dividend_type), get_dividend_pay_date(df)
    else:
        return None, None


def get_xdr_price(dividend_detail: pd.DataFrame, price: float) -> float:
    """获取除权除息价."""
    cash_dividend_rate = get_dividend_rate(dividend_detail, DividendType.CASH_DIVIDEND)
    stock_dividend_rate = get_dividend_rate(
        dividend_detail, DividendType.STOCK_DIVIDEND
    )
    conversion_ratio_rate = get_dividend_rate(
        dividend_detail, DividendType.CONVERSION_RATIO_DIVIDEND
    )
    xdr_price = (price - cash_dividend_rate) / (1 + stock_dividend_rate + conversion_ratio_rate)
    return round(xdr_price, 3)


def get_open_position_date(flow_df: pd.DataFrame) -> date:
    """获取建仓日期."""
    # 向前累加股票变动值
    flow_df["cum_stkeffect"] = flow_df["stkeffect"].cumsum()
    flow_df_liq = flow_df[flow_df["cum_stkeffect"] == 0].sort_index()
    if not flow_df_liq.empty:
        last_liq_date = flow_df_liq.iloc[-1]["tdate"]
        flow_df = flow_df[flow_df["tdate"] > last_liq_date].sort_index()
        return flow_df.iloc[0]["tdate"]  # type: ignore
    else:
        return flow_df.iloc[-1]["tdate"]  # type: ignore
