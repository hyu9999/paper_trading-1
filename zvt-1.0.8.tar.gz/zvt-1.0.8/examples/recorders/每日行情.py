# -*- coding: utf-8 -*-
import logging
import time
from apscheduler.schedulers.background import BackgroundScheduler
from zvt import init_log
from zvt.domain import *
from zvt.informer.informer import EmailInformer

logger = logging.getLogger(__name__)

sched = BackgroundScheduler()

index_code_list = ['000001', '000016', '000300', '000852', '000905', '399001', '399005', '399006', '399008', '399012', '399101', '399102', '399106', '399673','399107']

@sched.scheduled_job('cron', hour=14, minute=5)
def record_kdata():
    while True:
        email_action = EmailInformer()

        try:
            # FundDividendDetail.record_data(provider='joinquant', sleeping_time=0.1)
            # HolderTradePlan.record_data(provider='emquantapi', sleeping_time=0.1)
            # Stock1dKdata.record_data(exchanges=['a'], provider='emquantapi', sleeping_time=0.1)
            # StockEmotionFactor.record_data(schema='StockEmotionFactor', provider='joinquant', sleeping_time=0.1)
            # Stock1dBfqKdata.record_data(codes=['002147', '002160', '002162', '002163', '002164', '002173', '002175', '002176', '002188', '002190', '002192', '002194', '002199', '002200', '002207', '002210', '002217', '002219', '002220', '002234', '002247', '002248', '002255', '002256', '002259', '002260', '002263', '002265', '002280', '002289', '002290', '002306', '002312', '002319', '002323', '002333', '002336', '002354', '002356', '002359'], provider='joinquant', sleeping_time=0.1)
            # StockTradeDay.record_data(provider='joinquant', sleeping_time=0.1)
            # FinanceFactor.record_data(provider='joinquant', sleeping_time=0.1)
            # 股票
            # Stock.record_data(provider='eastmoney', sleeping_time=3)
            # StockDetail.record_data(provider='eastmoney', sleeping_time=3)
            # Stock1dKdata.record_data(provider='joinquant', sleeping_time=0.1, real_time=True)  # 前复权
            Stock1dBfqKdata.record_data(provider='joinquant', sleeping_time=0.1, real_time=True)  # 不复权
            Stock1dHfqKdata.record_data(provider='joinquant', sleeping_time=0.1, real_time=True)
            StockValuation.record_data(exchanges=['sh'],provider='emquantapi', sleeping_time=0.1)
            # StockValuation.record_data(exchanges=['sz'],provider='emquantapi', sleeping_time=0.1)
            # # 指数
            # IndexStockNew.record_data(codes=index_code_list, provider='joinquant', sleeping_time=0.1,real_time=True)
            # Index1dKdata.record_data(codes=index_code_list, provider='joinquant', sleeping_time=0.1,real_time=True)
            # IndexValuation.record_data(codes=index_code_list,provider='emquantapi', sleeping_time=0.1)


            # ETF
            # Etf.record_data(provider='joinquant', sleeping_time=0.1)
            # EtfStock.record_data(provider='joinquant', sleeping_time=0.1)
            # Etf1dKdata.record_data(provider='joinquant', sleeping_time=0.1,real_time=True)
            # Etf1dBfqKdata.record_data(provider='joinquant', sleeping_time=0.1, real_time=True)
            # Etf1dHfqKdata.record_data(provider='joinquant', sleeping_time=0.1, real_time=True)
            # 板块
            # Block1dKdata.record_data(provider='emquantapi', sleeping_time=0.1, real_time=True)
            # 十年期债券
            # Bond1dKdata.record_data(provider='emquantapi', sleeping_time=0.1, real_time=True)
            #
            # Fund.record_data(provider='joinquant', sleeping_time=0.1)
            # FundDetail.record_data(provider='joinquant', sleeping_time=0.1)
            # FundStock.record_data(provider='joinquant', sleeping_time=0.1)
            # FundNetValue.record_data(provider='joinquant', sleeping_time=0.1, real_time=True)

            # StockPerformanceForecast.record_data(provider='joinquant', sleeping_time=0.1)
            # HolderTrading.record_data(provider='emquantapi', sleeping_time=0.1)
            # EquityPledge.record_data(provider='joinquant', sleeping_time=0.1)
            # LockedShares.record_data(provider='joinquant', sleeping_time=0.1)
            #
            # Index1monKdata.record_data(provider='joinquant' ,sleeping_time=0.1)
            # Index1wkKdata.record_data(provider='joinquant',sleeping_time=0.1)
            # Stock1monBfqKdata.record_data(provider='joinquant', sleeping_time=0.1)
            # Stock1dHfqKdata.record_data(provider='joinquant', sleeping_time=0.1)
            # Stock1wkKdata.record_data(provider='joinquant', sleeping_time=0.1)
            # Stock1wkHfqKdata.record_data(provider='joinquant', sleeping_time=0.1)
            # Stock1wkBfqKdata.record_data(provider='joinquant', sleeping_time=0.1)

            # StockGrowthFactor.record_data(schema='StockGrowthFactor', provider='joinquant', sleeping_time=0.1)
            # StockMomentumFactor.record_data(schema='StockMomentumFactor', provider='joinquant', sleeping_time=0.1)

            break
        except Exception as e:
            msg = f'joinquant record kdata:{e}'
            logger.exception(msg)
            # email_action.send_message("327714319@qq.com", 'joinquant record kdata error', msg)
            time.sleep(60)

if __name__ == '__main__':
    init_log('joinquant_data_runner.log')
    # for i in range(1000):
    record_kdata()
    # record_others()
    # sched.start()
    # sched._thread.join()
