# -*- coding: utf-8 -*-
import logging
import time

from apscheduler.schedulers.background import BackgroundScheduler

from zvt import init_log
from zvt.domain import *
from zvt.informer.informer import EmailInformer

logger = logging.getLogger(__name__)

sched = BackgroundScheduler()


@sched.scheduled_job('cron', hour=15, minute=20)
def record_kdata():
    while True:
        email_action = EmailInformer()

        try:
            # StockValuationNew.record_data(exchanges=['sh'], provider='emquantapi', sleeping_time=0.1)
            FinancePerShare.record_data(provider='emquantapi', sleeping_time=0.1)

            email_action.send_message("327714319@qq.com", 'tonglian record kdata finished', '')
            break
        except Exception as e:
            msg = f'tonglian record kdata:{e}'
            logger.exception(msg)

            email_action.send_message("327714319@qq.com", 'tonglian record kdata error', msg)
            time.sleep(60)


@sched.scheduled_job('cron', hour=19, minute=00, day_of_week=3)
def record_others():
    while True:
        email_action = EmailInformer()

        try:
            Etf.record_data(provider='tonglian', sleeping_time=1)
            EtfStock.record_data(provider='tonglian', sleeping_time=1)

            email_action.send_message("327714319@qq.com", 'tonglian record etf finished', '')
            break
        except Exception as e:
            msg = f'tonglian record etf error:{e}'
            logger.exception(msg)

            email_action.send_message("327714319@qq.com", 'tonglian record etf error', msg)
            time.sleep(60)


if __name__ == '__main__':
    init_log('tonglian_data_runner.log')

    record_kdata()

    sched.start()

    sched._thread.join()
