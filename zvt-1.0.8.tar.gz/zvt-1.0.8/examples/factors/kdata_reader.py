from typing import List

from zvt.factors import ScoreFactor
