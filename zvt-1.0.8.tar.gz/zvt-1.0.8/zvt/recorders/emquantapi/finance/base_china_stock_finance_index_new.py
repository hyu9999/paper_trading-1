# -*- coding: utf-8 -*-
import pandas as pd
from jqdatasdk import get_factor_values

from zvt.contract.recorder import TimestampsDataRecorder, FixedCycleDataRecorder

from zvt.recorders.joinquant.common import JoinquantTimestampsDataRecorder, call_joinquant_api, get_from_path_fields, \
    get_fc, to_jq_entity_id
from zvt.api import to_report_period_type
from zvt.contract.api import df_to_db, get_data
from zvt.domain import StockDetail, FinancePerShare, BalanceSheet
from zvt.recorders.emquantapi.common import mainCallback, to_em_entity_id
from zvt.utils.pd_utils import pd_is_not_null
from zvt.utils.time_utils import to_time_str, TIME_FORMAT_DAY, now_pd_timestamp, to_pd_timestamp
from jqdatasdk import auth, get_query_count, get_factor_values
from datetime import timedelta
try:
    from EmQuantAPI import c
except:
    pass


class EmBaseChinaStockFinanceRecorder2(FixedCycleDataRecorder):
    finance_report_type = None
    data_type = 1

    entity_provider = 'joinquant'
    entity_schema = StockDetail
    provider = 'emquantapi'

    def __init__(self, entity_type='stock', exchanges=['sh', 'sz'], entity_ids=None, codes=None, batch_size=10,
                 force_update=False, sleeping_time=5, default_size=2000, real_time=False,
                 fix_duplicate_way='add', start_timestamp=None, end_timestamp=None, close_hour=0,
                 close_minute=0) -> None:
        super().__init__(entity_type, exchanges, entity_ids, codes, batch_size, force_update, sleeping_time,
                         default_size, real_time, fix_duplicate_way, start_timestamp, end_timestamp, close_hour,
                         close_minute)

        # 调用登录函数（激活后使用，不需要用户名密码）
        loginResult = c.start("ForceLogin=1", '', mainCallback)
        if (loginResult.ErrorCode != 0):
            print("login in fail")
            exit()

        auth("13501148196", "JinChongZi321")
        print(f"剩余{get_query_count()['spare'] / 10000}万")

    def on_finish(self):
        # 退出
        loginresult = c.stop()
        if (loginresult.ErrorCode != 0):
            print("login in fail")
            exit()


    def record(self, entity, start, end, size, timestamps):
        old_timestamp = self.data_schema.query_data(entity_id=entity.id, limit=1, order=self.data_schema.timestamp.desc())
        if not old_timestamp.empty:
            if to_time_str(old_timestamp.pub_date.values[0])>= '2020-09-30':
                return None
            else:
                old_timestamp = old_timestamp.timestamp.values[0]
        else:
            old_timestamp = '1990-01-01'
        # if entity.id in ['stock_sz_000022','stock_sz_000406','stock_sz_003030'] or '退' in entity.name:
        #     return None

        if self.finance_report_type == 'FinanceGrowthAbility':
            from zvt.domain import FinanceGrowthAbility
            data_old = FinanceGrowthAbility.query_data(entity_id=entity.id)
        if self.finance_report_type == 'FinancePerShare':
            from zvt.domain import FinancePerShareOld
            data_old = FinancePerShareOld.query_data(entity_id=entity.id,start_timestamp=old_timestamp)

        if self.finance_report_type == 'FinanceProfitAbility':
            from zvt.domain import FinanceProfitAbility
            data_old = FinanceProfitAbility.query_data(entity_id=entity.id,)

        if self.finance_report_type == 'FinanceReceivingAbility':
            from zvt.domain import FinanceReceivingAbility
            data_old = FinanceReceivingAbility.query_data(entity_id=entity.id)
        if self.finance_report_type == 'FinanceCapitalStructure':
            from zvt.domain import FinanceCapitalStructure
            data_old = FinanceCapitalStructure.query_data(entity_id=entity.id)
        if self.finance_report_type == 'FinanceDebtpayingAbility':
            from zvt.domain import FinanceDebtpayingAbility
            data_old = FinanceDebtpayingAbility.query_data(entity_id=entity.id)
        if self.finance_report_type == 'FinanceBalanceSheetStructureAnalysis':
            from zvt.domain import FinanceBalanceSheetStructureAnalysis
            data_old = FinanceBalanceSheetStructureAnalysis.query_data(entity_id=entity.id)
        if self.finance_report_type == 'FinanceOperationalCapability':
            from zvt.domain import FinanceOperationalCapability
            data_old = FinanceOperationalCapability.query_data(entity_id=entity.id)
        if self.finance_report_type == 'FinanceDuPont':
            from zvt.domain import FinanceDuPont
            data_old = FinanceDuPont.query_data(entity_id=entity.id)

        if 'pub_date' in data_old.columns:
            del data_old['pub_date']
        dict_ps = self.get_data_map2()
        data_pub_date = BalanceSheet.query_data(entity_id=entity.id, columns=['pub_date', 'id'],start_timestamp=old_timestamp)
        if data_pub_date.empty or data_pub_date.shape[0] == 1:
            return None
        del data_pub_date['timestamp']
        df_old_all = pd.merge(data_old, data_pub_date, on=['id'])
        df_old_all.rename(columns=dict_ps, inplace=True)
        if df_old_all.empty:
            return
        columns_map = {key: value[0] for key, value in self.get_data_map().items()}
        init_list = ['pub_date', 'id', 'entity_id', 'timestamp', 'provider', 'code', 'report_period', 'report_date']
        get_data_list = [i for i in columns_map if i not in df_old_all.columns and i not in init_list]
        choice_list = [j for k, j in columns_map.items() if k in get_data_list]
        # jq_columns= {
        #     "cf_ps_ttm": "cashflow_per_share_ttm",  # 每股现金流量净额TTM(元)
        #     "or_ps_ttm": "operating_revenue_per_share_ttm",  # 每股营业收入TTM(元)
        #     "eps_ttm": "eps_ttm",  # 每股收益EPSTTM(元)
        # }

        # em_code = to_em_entity_id(entity)
        # jq_df =  pd.DataFrame()
        # for jq_date in df_old_all['pub_date'].to_list():
        #     factor_data = get_factor_values(securities=[to_jq_entity_id(entity)],
        #                                 factors=list(jq_columns.values()),
        #                                 end_date=jq_date + timedelta(days=3), count=1)
        #     if factor_data == {}:
        #         continue
        #     jqdata = pd.DataFrame(index=[jq_date])
        #     for col in list(jq_columns.values()):
        #         jqdata[col] = factor_data[col].values[0][0]
        #     jqdata['pub_date'] = jq_date
        #     jq_df = jq_df.append(jqdata)
        # jq_df.rename(columns=dict([val,key] for key,val in jq_columns.items()),inplace=True)
        # if not jq_df.empty:
        #     df_old_all = pd.merge(df_old_all,jq_df,on=['pub_date'])
        # df_old_all = df_old_all.drop_duplicates('id')

        df_old_all['provider'] = 'emquantapi'
        df_old_all['timestamp'] = df_old_all['pub_date']
        df_to_db(df=df_old_all, data_schema=self.data_schema, provider=self.provider, force_update=True)
        return

        choice_list = ['CFOPSTTM','EPSEXBASIC']
        df = pd.DataFrame()
        for reportdate in df_old_all.report_date.to_list():
            em_data = c.css(em_code, choice_list, "ispandas=1,TtmType=1,TradeDate=" + to_time_str(
                reportdate) + ",ReportDate=" + to_time_str(reportdate))
            if type(em_data) == pd.DataFrame:
                em_data['report_date'] = to_time_str(reportdate)
                df = df.append(em_data)
        if df.empty:
            return None
        df.rename(columns={value: key for key, value in columns_map.items()}, inplace=True)

        df = df.sort_values("report_date", ascending=True)
        if pd_is_not_null(df):
            df.rename(columns={value: key for key, value in columns_map.items()}, inplace=True)
            df['entity_id'] = entity.id

            def generate_id(se):
                return "{}_{}".format(se['entity_id'], to_time_str(se['report_date'], fmt=TIME_FORMAT_DAY))

            df['id'] = df[['entity_id', 'report_date']].apply(generate_id, axis=1)
            del df['entity_id'], df['report_date']
            data_res = pd.merge(df, df_old_all, on=['id'])
            data_res['provider'] = 'emquantapi'
            data_res['timestamp'] = data_res['pub_date']
            df_to_db(df=data_res, data_schema=self.data_schema, provider=self.provider, force_update=True)
        return None

    def record2(self, entity, start, end, size, timestamps):
        param = self.generate_request_param(entity, start, end, size, timestamps)

        if not end:
            end = to_time_str(now_pd_timestamp())
        start = to_time_str(start)
        em_code = to_em_entity_id(entity)
        df = pd.DataFrame()
        columns_map = {key: value[0] for key, value in self.get_data_map().items()}
        columns_list = list(columns_map.values())
        if self.finance_report_type == 'AuditOpinions':
            # 审计意见数据只有年报有
            param = [i for i in param if '12-31' in i]
        for reportdate in param:
            # 获取数据
            # 三大财务报表 使用ctr方法读取表名
            if self.data_type < 4:
                em_data = c.ctr(self.finance_report_type, columns_list,
                                "secucode=" + em_code + ",ReportDate=" + reportdate + ",ReportType=1")
                if em_data.Data == {}:
                    continue
                data = pd.DataFrame(em_data.Data['0']).T
                data.columns = em_data.Indicators
                data['report_date'] = reportdate
                df = df.append(data)
            # 否则用 css方法读取单个指标
            else:
                em_data = c.css(em_code, columns_list, "ispandas=1,ReportDate=" + reportdate)
                if type(em_data) == pd.DataFrame:
                    em_data['report_date'] = reportdate
                    if 'FIRSTNOTICEDATE' not in columns_list:
                        em_data['pub_date'] = end
                    df = df.append(em_data)
        if df.empty:
            return None
        df.rename(columns={value: key for key, value in columns_map.items()}, inplace=True)
        df = df.sort_values("report_date", ascending=True)
        if pd_is_not_null(df):
            df.rename(columns={value: key for key, value in columns_map.items()}, inplace=True)
            df['entity_id'] = entity.id
            df['timestamp'] = pd.to_datetime(df.report_date)
            df['provider'] = 'emquantapi'
            df['code'] = entity.code
            df['report_period'] = df['report_date'].apply(lambda x: to_report_period_type(x))

            def generate_id(se):
                return "{}_{}".format(se['entity_id'], to_time_str(se['timestamp'], fmt=TIME_FORMAT_DAY))

            df['id'] = df[['entity_id', 'timestamp']].apply(generate_id, axis=1)
            df_to_db(df=df, data_schema=self.data_schema, provider=self.provider, force_update=self.force_update)
        return None

    def get_original_time_field(self):
        return 'ReportDate'
