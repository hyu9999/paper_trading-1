# -*- coding: utf-8 -*-
from zvt.domain import FinanceProfitAbility
from zvt.recorders.emquantapi.finance.base_china_stock_finance_index import EmBaseChinaStockFinanceIndexRecorder
from zvt.utils.utils import add_func_to_value, first_item_to_float

financial_profitability_map = {
    # 净资产收益率ROE(摊薄)(%)
    'roe_diluted': 'ROEDILUTED',
    # 净资产收益率ROE(平均)(%)
    'roe_avg': 'ROEAVG',
    # 净资产收益率ROE(加权)(%)
    'roe_wa': 'ROEWA',
    # 净资产收益率ROE(扣除/摊薄)(%)
    'roe_ex_diluted': 'ROEEXDILUTED',
    # 净资产收益率ROE(扣除/加权)(%)
    'roe_ex_wa': 'ROEEXWA',

    # 总资产报酬率ROA(%)
    'roa': 'ROA',
    # 投入资本回报率ROIC(%)
    'roic': 'ROIC',
    # 净资产收益率ROE(TTM)(%)
    'roe_ttm': 'ROETTM',
    # 总资产报酬率ROA(TTM)(%)
    'roa_ttm': 'ROATTM',
    # 总资产净利率ROA(%)
    'net_roa': 'NROA',
    # 总资产净利率(TTM)(%)
    'n_roa_ttm': 'NROATTM',
    # 销售净利率(%)
    'np_margin': 'NPMARGIN',
    # 销售净利率(TTM)(%)
    'np_margin_ttm': 'NPMARGINTTM',

    # 销售毛利率(%)
    'gp_margin': 'GPMARGIN',
    # 销售毛利率(TTM)(%)
    'gp_margin_ttm': 'GPMARGINTTM',

    # 销售期间费用率(%)
    'expense_to_or': 'EXPENSETOOR',
    # 销售期间费用率(TTM)(%)
    'expense_to_ors_ttm': 'EXPENSETOORSTTM',
    # 净利润/营业总收入(%)
    'ni_to_gr': 'NITOGR',
    # 净利润/营业总收入(TTM)(%)
    'ni_to_gr_ttm': 'NITOGRTTM',
    # 营业利润/营业总收入(%)
    'op_to_gr': 'OPTOGR',
    # 营业利润/营业总收入(TTM)(%)
    'op_to_gr_ttm': 'OPTOGRTTM',
    # 营业总成本/营业总收入(TTM)(%)
    'gc_to_gr_ttm': 'GCTOGRTTM',
    # 营业费用/营业总收入(TTM)(%)
    'operae_expense_to_gr_ttm': 'OPERATEEXPENSETOGRTTM',
    # 管理费用/营业总收入(TTM)(%)
    'admin_expense_to_gr_ttm': 'ADMINEXPENSETOGRTTM',
    # 财务费用/营业总收入(TTM)(%)
    'fina_expense_to_gr_ttm': 'FINAEXPENSETOGRTTM',
    # 资产减值损失/营业总收入(TTM)(%)
    'impart_to_gr_ttm': 'IMPAIRTOGRTTM',
    # 净资产收益率ROETTM(扣非)(%)
    'deducted_roe_ttm': 'ROETTMDEDUCTED',
    # 投入资本回报率ROIC(TTM)(%)
    'roic_ttm': 'ROICTTM',
    # 成本费用利润率(%)
    'np_to_cost_expense': 'NPTOCOSTEXPENSE',
    # 研发费用/营业总收入(%)
    'rd_expense_to_gr': 'RDEXPENSETOGR',
}

add_func_to_value(financial_profitability_map, first_item_to_float)


class ChinaStockFinanceProfitAbilityRecorder(EmBaseChinaStockFinanceIndexRecorder):
    """
    财务指标-盈利能力
    """
    data_schema = FinanceProfitAbility

    finance_report_type = 'FinanceProfitAbility'

    data_type = 8

    def get_data_map(self):
        return financial_profitability_map


__all__ = ['ChinaStockFinanceProfitAbilityRecorder']

if __name__ == '__main__':
    # init_log('income_statement.log')
    # from zvt.domain import *
    #
    # stock_list = Stock.query_data(filters=[Stock.exchange.contains('sh')])
    # stock_list = sorted(stock_list.entity_id.tolist())
    # B, C = stock_list[:int(len(stock_list) / 2)], stock_list[int(len(stock_list) / 2):]
    recorder = ChinaStockFinanceProfitAbilityRecorder(sleeping_time=0.1)
    recorder.run()
