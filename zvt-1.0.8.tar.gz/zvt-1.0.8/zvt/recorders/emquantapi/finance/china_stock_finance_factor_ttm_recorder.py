# -*- coding: utf-8 -*-
from zvt.utils.utils import add_func_to_value, to_float
from zvt.domain import FinanceFactorTTM
from zvt.recorders.emquantapi.finance.base_china_stock_finance_index import EmBaseChinaStockFinanceIndexRecorder

finance_factor_map = {
    # 营业总收入TTM
    "total_op_income_ttm": "GRTTMR",
    # 营业总成本TTM
    "total_operating_costs_ttm": "GCTTMR",
    # 营业收入TTM
    "operating_income_ttm": "ORTTMR",
    # 营业成本非金融类TTM
    "oc_ttm": "OCTTMR",
    # 营业支出金融类TTM
    "expense_ttm": "EXPENSETTMR",
    # 毛利TTM
    "fi_gross_margin_ttm": "GROSSMARGINTTMR",
    # 销售费用TTM
    "sales_costs_ttm": "OPERATEEXPENSETTMR",
    # 管理费用TTM
    "managing_costs_ttm": "ADMINEXPENSETTMR",
    # 财务费用TTM
    "financing_costs_ttm": "FINAEXPENSETTMR",
    # 资产减值损失TTM
    "assets_devaluation_ttm": "IMPAIRMENTTTMR",
    # 经营活动净收益TTM
    "fi_operate_income_ttm": "OPERATEINCOMETTMR",
    # 价值变动净收益TTM
    "fi_investment_income_ttm": "INVESTINCOMETTMR",
    # 营业利润TTM
    "operating_profit_ttm": "OPTTMR",
    # 营业外收支净额TTM
    "non_op_profit_ttm": "NONOPERATEPROFITTTMR",
    # 息税前利润TTM
    "fi_ebit_ttm": "EBITTTMR",
    # 利润总额TTM
    "total_profits_ttm": "EBTTTMR",
    # 所得税TTM
    "tax_ttm": "TAXTTMR",
    # 归属母公司股东的净利润TTM
    "net_profit_as_parent_ttm": 'PNITTMR',
    # 扣除非经常性损益净利润TTM
    "fi_deducted_income_ttm": "KCFJCXSYJLRTTMR",
    # 净利润TTM
    "net_profit_ttm": "NPTTMRP",
    # 公允价值变动损益TTM
    "fvvpalrp_ttm": "FVVPALRP",
    # 投资收益TTM
    "investment_income_ttm": "IRTTMRP",
    # 对联营企业和合营企业的投资收益TTM
    "iittmjvajvrp_ttm": "IITTMFJVAJVRP",
    # 营业税金及附加TTM
    "btaa_ttm": "BTAATTMRP",
    # 销售商品提供劳务收到的现金TTM
    "sales_cash_in_ttm": "SALESCASHINTTMR",
    # 经营活动现金净流量TTM
    "cfo_ttm": "CFOTTMR",
    # 投资活动现金净流量TTM
    "cfi_ttm": "CFITTMR",
    # 筹资活动现金净流量TTM
    "cff_ttm": "CFFTTMR",
    # 现金净流量TTM
    "cf_ttm": "CFTTMR",
    # 资本支出TTM
    "capexr_ttm": "CAPEXR",
}

add_func_to_value(finance_factor_map, to_float)


class ChinaStockFinanceFactorRecorder(EmBaseChinaStockFinanceIndexRecorder):
    finance_report_type = 'Finance_Factor_TTM'

    data_schema = FinanceFactorTTM
    data_type = 4

    def get_data_map(self):
        return finance_factor_map


__all__ = ['ChinaStockFinanceFactorRecorder']

if __name__ == '__main__':
    # init_log('finance_factor.log')
    recorder = ChinaStockFinanceFactorRecorder(exchanges=['sh'],sleeping_time=0.1)
    # recorder = ChinaStockFinanceFactorRecorder(entity_ids=['stock_sz_000017'],sleeping_time=0.1)
    recorder.run()
