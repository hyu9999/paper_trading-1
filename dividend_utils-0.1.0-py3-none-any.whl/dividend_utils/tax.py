import datetime

import pandas as pd
from dateutil import relativedelta

from dividend_utils.dividend import get_dividend_rate
from dividend_utils.enums import DividendType


def calculate_tax(
    flow_df: pd.DataFrame, dividend_df: pd.DataFrame, volume: int, tdate: datetime.date
) -> float:
    """计算税额."""
    # 分阶段计算持股数
    last_month = tdate + relativedelta.relativedelta(months=-1)  # noqa
    last_year = tdate + relativedelta.relativedelta(years=-1)  # noqa
    tax_rate_mapping = {
        0: "tdate < @last_year",
        0.1: "(tdate >= @last_year) and (tdate < @last_month)",
        0.2: "tdate >= @last_month",
    }
    tax = 0.0
    # 获取分红率
    cash_rate = get_dividend_rate(dividend_df, DividendType.CASH_DIVIDEND)
    stock_rate = get_dividend_rate(dividend_df, DividendType.STOCK_DIVIDEND)
    dividend_rate = cash_rate + stock_rate
    for tax_rate, query_str in tax_rate_mapping.items():
        # 阶段持仓量
        stage_volume = flow_df.query(query_str).stkeffect.sum()
        if volume == 0:
            break
        if stage_volume > volume:
            amount = dividend_rate * volume
            volume = 0
        else:
            amount = dividend_rate * stage_volume
            volume -= stage_volume
        tax += amount * tax_rate
    return tax
